## Grass Top + Sides Fix (v5.3)

### Changed
- Top face is green again.
- Side faces rebuilt from dirt with a consistent grass strip.
- Bottom face matches dirt for consistency.

### Fixes
- Removed broken side seams on grass blocks.
- Grass now looks correct from all angles.

### Technical Impact
- No layout changes; still a 48x32 cube-net per block.
- Fully compatible with the existing runtime atlas build.

---

*Greener tops, cleaner sides.*
